import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-arquivos',
  templateUrl: './arquivos.page.html',
  styleUrls: ['./arquivos.page.scss'],
})
export class ArquivosPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
